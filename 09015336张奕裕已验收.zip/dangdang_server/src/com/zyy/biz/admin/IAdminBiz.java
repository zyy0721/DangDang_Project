package com.zyy.biz.admin;

public interface IAdminBiz {
	/**
	 * ����Ա��¼У��
	 * @param name
	 * @param pwd
	 * @return
	 */
	public String validateLogin(String name,String pwd);
}
